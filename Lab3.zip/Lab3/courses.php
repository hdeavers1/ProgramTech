<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "it1150";

$conn = mysqli_connect($servername, $username, $password, $dbname); 

if($conn === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

$sql = "SELECT course_id, title, credit_hrs, description, prerequisites FROM courses";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
  // output data of each row
  while($row = mysqli_fetch_assoc($result)) {
    echo "Course ID: " . $row["course_id"]. " Title: " . $row["title"]. " Credit Hours: " . $row["credit_hrs"]. " Description:" . $row["description"]. " Prerequisites: " . $row["prerequisites"]."<br>"."<br>";
  }
} else {
  echo "0 results";
}

mysqli_close($conn);
?>