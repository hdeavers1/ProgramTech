<!DOCTYPE html>
<html>
    <head>
        <title>Lab 6 Deavers</title>
            <style> 
                word-wrap:break-word;
                white-space:normal;
            </style>
    </head>
<body> 
    <h2>Lab 6 Deavers</h2>

    <h3>1. Name:</h3>
    <?php
    $firstname = $_POST['first'];
    $middlename = str_split("$_POST[middle]");
    $lastname = $_POST['last'];
    echo ("$firstname"." "."$middlename[0]."." "."$lastname");
    ?>

    <h3>2. Split:</h3>
    <?php
    $split = $_POST['split'];
    $explosion = explode("-", $split);
    $count = count($explosion);
    for ($x=0; $x<$count; $x++) {
        echo nl2br("$explosion[$x]\n");
    }

    ?>
    <h3>3. Shuffle</h3>
    <?php
    $random = $_POST['shuffle'];
    $shuffled = str_shuffle($_POST['shuffle']);
    echo ($shuffled);
    ?>

    <h3>4. To Lower</h3>
    <?php
    $lower = strtolower($_POST['tolower']);
    echo $lower;
    ?>

    <h3>5. Compare</h3>
    <?php
    $compare1 = $_POST['compare1'];
    $compare2 = $_POST['compare2'];
    echo nl2br("$compare1\n");
    echo nl2br("$compare2\n");
    ?>
    <h4>A. strcmp:</h4>
    <?php
    if (strcmp($compare1, $compare2) !== 0){
        echo 'Not equal in case sensitive string comparison';
    }
    ?>
    <h4>B. strcasecmp:</h4>
    <?php
    if (strcasecmp($compare1, $compare2) == 0){
        echo 'They are equal in case-insensitive string comparison';
    }
    ?>

    <h4>6. Num Compare</h4>
    <?php
    $num1 = $_POST['num1'];
    $num2 = $_POST['num2'];
    echo nl2br("1."."$num1\n");
    echo nl2br("2."."$num2\n");
    ?>
    <h4>A. Minimum</h4>
    <?php
    echo min($num1, $num2);
    ?>
    <h4>B. Maximum</h4>
    <?php
    echo max($num1, $num2);
    ?>
    <h4>C. Average</h4>
    <?php
    $average = (($num1 + $num2)/2);
    echo $average;
    ?>

    <h4>7. Random</h4>
    <?php
    echo rand(1, 100);
    ?>

    <h4>8. Currency</h4>
    <?php
    $currency = $_POST['currency'];
    $formatted = sprintf("%01.2f", $currency);
    echo ("$"."$formatted");
    ?>

    <h4>9. Date and Time</h4>
    <?php
    $year = $_POST['year'];
    $month = $_POST['month'];
    $day = $_POST['day'];
    $hour = $_POST['hour'];
    $minute = $_POST['minute'];

    $date=mktime($hour, $minute, 0, $month, $day, $year);

    echo ("Date 1: " . date("Y-m-d h:i:sa", $date));
    echo nl2br ("\nDate 2: " . date("h:i:sa m-d-Y", $date));
    ?>

    <h4>10. Hours between Date and Now</h4>
    <?php
    date_default_timezone_set("America/New_York");
    $startdate = strtotime("now");
    echo ("Today's date is " . date("Y-m-d h:i:sa", $startdate));
    echo nl2br ("\nFuture Date is : " . date("Y-m-d h:i:sa", $date)."\n");
    $origin = new DateTimeImmutable("now");
    $target = new DateTimeImmutable("2023-11-01 07:05:00 America/New_York");
    $interval = $origin->diff($target);
    $hours = $interval->h;
    $hours = $hours + ($interval->days*24);
    echo ("The amount of hours between the two are " . "$hours");
    ?>




