<!DOCTYPE html>
<html>
<head>
<title>Investment Calculator</title>
<style>
    td, th { text-align: right }
    td {padding:4px; width: 110px; }
    tr:nth-child(even) {background-color: #e5e5e5; }
    tr {border-bottom:1px solid #cccccc; }
    .year {width:30px;}
</style>
</head>
<body>
    <h1>Simple Investment Calculator</h1>
    <?php
    setlocale(LC_MONETARY,"en_US");

    $newamount = $_POST['amount'];
    $rate = $_POST['rate'];
    $years = $_POST['years'];
    $extra = $_POST['extra'];
    $addamount = $_POST['addamount'];
    ?>

    <h3>Investment Details</h3>
    <?php

    echo nl2br("New amount: $newamount\n");
    echo nl2br("Rate: $rate\n"); 
    echo nl2br("Years: $years\n"); 
    echo nl2br("Extra: $extra\n"); ;
    echo nl2br("Add Amount: $addamount\n"); 
    ?>

    <h3>Annual Schedule</h3>
    <table>
        <tr>
            <th>Year</th>
            <th>Start Amount</th>
            <th>Interest</th>
            <th>End Amount</th>
            <th>Extra Amount</th>
            <th>Final Amount</th>
        </tr>
    <?php
 
    for ($x=0; $x<$years; $x++) {
        $startamount = $newamount;
        $interest = $newamount * ($rate/100);

        if($addamount == "Yes")
        {
            $newamount = $newamount + $extra;
            
        }
        $newamount = $newamount + $interest;
    ?>
    <tr>
        <td class="year"><?php echo ($x+1); ?>
        <td><?php printf ( "$%.02f" , $startamount ); ?></td>
        <td><?php printf ( "$%.02f" , $interest ); ?></td>
        <td><?php printf ( "$%.02f" , $newamount ); ?></td>
    
        <td><?php if($addamount === "Yes") { printf ( "$%.02f" , $extra ); } ?></td>
        <td><?php if($addamount === "Yes") { printf ( "$%.02f" , $newamount ); } ?></td>

    <?php
    }
    ?>
</body>
</html>